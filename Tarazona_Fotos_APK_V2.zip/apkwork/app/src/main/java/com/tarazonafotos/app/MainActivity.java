package com.tarazonafotos.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    boolean dark;
    SharedPreferences prefs;
    final int YELLOW = Color.rgb(243,181,27);

    int bg(){ return Color.parseColor(dark ? "#101114" : "#F5F4F1"); }
    int fg(){ return Color.parseColor(dark ? "#FFFFFF" : "#202124"); }
    int muted(){ return Color.parseColor(dark ? "#B8BBC2" : "#66686D"); }
    int card(){ return Color.parseColor(dark ? "#1B1D21" : "#FFFFFF"); }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("tarazona", MODE_PRIVATE);
        dark=prefs.getBoolean("dark", false);
        showHome();
    }

    TextView tv(String s,float size,boolean bold){
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(fg());
        t.setGravity(Gravity.CENTER_VERTICAL);
        if(bold) t.setTypeface(null,1);
        t.setPadding(18,10,18,10);
        return t;
    }

    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextColor(fg());
        b.setAllCaps(false); b.setBackgroundColor(Color.TRANSPARENT); return b;
    }

    LinearLayout cardLayout(){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(12,12,12,12);
        GradientDrawable g=new GradientDrawable(); g.setColor(card()); g.setCornerRadius(28); l.setBackground(g);
        return l;
    }

    void base(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg()); setContentView(root);
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(8,8,8,8);
        TextView menu=tv("☰",27,false); bar.addView(menu,new LinearLayout.LayoutParams(55,60));
        TextView name=tv("Tarazona Fotos",21,true); bar.addView(name,new LinearLayout.LayoutParams(0,60,1));
        TextView mode=tv(dark?"☀":"🌙",24,false); bar.addView(mode,new LinearLayout.LayoutParams(55,60));
        mode.setOnClickListener(v->{ dark=!dark; prefs.edit().putBoolean("dark",dark).apply(); showHome(); });
        root.addView(bar);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(8,4,8,12);
        ScrollView sv=new ScrollView(this); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setBackgroundColor(card());
        addNav(nav,"⌂\nInicio",()->showHome()); addNav(nav,"▣\nÁlbumes",()->showAlbums()); addNav(nav,"♡\nFavoritos",()->showFavorites());
        addNav(nav,"⇩\nDescargas",()->showDownloads()); addNav(nav,"☺\nPerfil",()->showProfile()); root.addView(nav);
    }

    void addNav(LinearLayout nav,String label,final Runnable r){ Button b=btn(label); b.setTextSize(11); b.setOnClickListener(v->r()); nav.addView(b,new LinearLayout.LayoutParams(0,72,1)); }

    void title(String s,String sub){ content.addView(tv(s,24,true)); if(sub!=null) content.addView(tv(sub,14,false)); }

    void showHome(){ base();
        TextView hero=tv("Nuestros momentos,\npara siempre",28,true); hero.setTextColor(Color.WHITE); hero.setPadding(24,28,24,28);
        GradientDrawable hg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(35,38,45),Color.rgb(110,80,35)}); hg.setCornerRadius(34); hero.setBackground(hg);
        content.addView(hero,new LinearLayout.LayoutParams(-1,190));
        content.addView(tv("Álbumes recientes",22,true));
        String[][] albums={{"Fallas 2026","523 fotos · 15 marzo 2026"},{"Nit Jove 2026","318 fotos"},{"Presentación 2026","245 fotos"},{"REMEMBER RAVAL 26","412 fotos"}};
        for(String[] a:albums) addAlbumCard(a[0],a[1]);
        content.addView(tv("Acciones rápidas",22,true));
        LinearLayout actions=cardLayout(); actions.addView(tv("⭐  Favoritos     🔔  Notificaciones",16,false)); actions.addView(tv("⬇  Descargas     🔎  Buscar fotos y álbumes",16,false)); content.addView(actions);
    }

    void addAlbumCard(String name,String info){
        LinearLayout c=cardLayout(); c.setClickable(true); c.setOnClickListener(v->showAlbum(name,info));
        TextView t=tv("📷  "+name,18,true); c.addView(t); c.addView(tv(info+"   ·   Ver álbum  →",14,false));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,95); lp.setMargins(4,7,4,7); content.addView(c,lp);
    }

    void showAlbums(){ base(); title("Álbumes","Todos tus recuerdos organizados por eventos");
        String[][] albums={{"Fallas 2026","523 fotos · 15 marzo 2026"},{"Nit Jove 2026","318 fotos"},{"Presentación 2026","245 fotos"},{"REMEMBER RAVAL 26","412 fotos"},{"Fallas 2025","1.248 fotos"}};
        for(String[] a:albums) addAlbumCard(a[0],a[1]);
    }

    void showAlbum(String name,String info){ base();
        Button back=btn("‹  Volver"); back.setOnClickListener(v->showAlbums()); content.addView(back,new LinearLayout.LayoutParams(-1,55));
        title(name,info); content.addView(tv("Todas     Fotos     Vídeos                 ▦",15,true));
        GridLayout grid=new GridLayout(this); grid.setColumnCount(3); grid.setPadding(4,8,4,8);
        for(int i=1;i<=18;i++){
            TextView p=tv("📸\n"+i,14,true); p.setGravity(Gravity.CENTER); p.setTextColor(Color.WHITE);
            GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(65+(i*7)%70,45+(i*9)%70,35+(i*5)%70),Color.rgb(120+(i*3)%80,90+(i*4)%70,40+(i*6)%70)}); g.setCornerRadius(18); p.setBackground(g);
            GridLayout.LayoutParams gp=new GridLayout.LayoutParams(); gp.width=0; gp.height=112; gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f); gp.setMargins(4,4,4,4); grid.addView(p,gp);
            final int n=i; p.setOnClickListener(v->showPhoto(name,n));
        }
        content.addView(grid);
        content.addView(tv("Seleccionar     ⬇ Descargar     ♡ Favorito     ↗ Compartir",15,true));
    }

    void showPhoto(String album,int number){ base(); Button back=btn("‹  Volver al álbum"); back.setOnClickListener(v->showAlbum(album,"523 fotos")); content.addView(back,new LinearLayout.LayoutParams(-1,55));
        title(number+" de 523",album); TextView photo=tv("📷\n\nFoto de ejemplo\n\nAquí aparecerá la fotografía real",18,true); photo.setTextColor(Color.WHITE); photo.setGravity(Gravity.CENTER);
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(30,32,38),Color.rgb(125,85,30)}); g.setCornerRadius(28); photo.setBackground(g); content.addView(photo,new LinearLayout.LayoutParams(-1,420));
        content.addView(tv("♡ 28       💬 5",18,true)); content.addView(tv("⬇ Descargar     ♡ Favorito     💬 Comentar     ↗ Compartir",15,true));
    }

    void showFavorites(){ base(); title("Favoritos","Tus fotos y recuerdos guardados");
        LinearLayout c=cardLayout(); c.addView(tv("♡  Aún no tienes favoritos",20,true)); c.addView(tv("Cuando marques una foto como favorita aparecerá aquí.",14,false)); content.addView(c);
    }
    void showDownloads(){ base(); title("Descargas","Fotos guardadas en el dispositivo");
        LinearLayout c=cardLayout(); c.addView(tv("⬇  No hay descargas todavía",20,true)); c.addView(tv("Las fotos que descargues aparecerán aquí.",14,false)); content.addView(c);
    }
    void showProfile(){ base(); title("Mi perfil","Tarazona Fotos · Falla Raval d’Alcàsser");
        LinearLayout c=cardLayout(); c.addView(tv("👤  Miguel Ángel",20,true)); c.addView(tv("Cuenta privada\n\n🔔 Notificaciones\n🔐 Privacidad\n📩 Solicitar retirada de una foto\nℹ️ Sobre Tarazona Fotos",15,false)); content.addView(c);
    }
}
