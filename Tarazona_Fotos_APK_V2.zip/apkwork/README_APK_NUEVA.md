# Tarazona Fotos APK — nueva base
Aplicación Android propia, independiente visualmente de la web.
Incluye base de navegación, álbumes, favoritos, descargas, perfil y selector claro/noche.
Esta versión es la base de interfaz; la conexión con datos reales se añadirá después.
