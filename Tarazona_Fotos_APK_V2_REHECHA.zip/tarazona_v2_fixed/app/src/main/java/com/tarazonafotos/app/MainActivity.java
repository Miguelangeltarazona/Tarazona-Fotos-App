package com.tarazonafotos.app;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content, nav; boolean dark=false; SharedPreferences prefs;
    int orange=Color.rgb(255,107,53);
    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("prefs",0);dark=prefs.getBoolean("dark",false);showHome();}
    TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setPadding(18,12,18,12);t.setTextColor(dark?Color.WHITE:Color.rgb(30,30,30));return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(dark?Color.WHITE:Color.DKGRAY);return b;}
    void base(String title){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(dark?Color.rgb(18,18,18):Color.rgb(250,250,250));
      LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);TextView h=tv("☰   "+title,20);h.setTypeface(null,1);bar.addView(h,new LinearLayout.LayoutParams(0,64,1));Button search=btn("⌕");bar.addView(search,new LinearLayout.LayoutParams(60,64));root.addView(bar);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);ScrollView sc=new ScrollView(this);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
      nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);String[] ns={"Inicio","Álbumes","Favoritos","Descargas","Perfil"};for(String n:ns){Button x=btn(n);x.setOnClickListener(v->{if(n.equals("Inicio"))showHome();else if(n.equals("Álbumes"))showAlbums();else if(n.equals("Favoritos"))showFavorites();else if(n.equals("Descargas"))showDownloads();else showProfile();});nav.addView(x,new LinearLayout.LayoutParams(0,65,1));}root.addView(nav);setContentView(root);}
    void showHome(){base("Tarazona Fotos");TextView hero=tv("FALLA RAVAL D’ALCÀSSER\n\nNuestros momentos, para siempre",25);hero.setPadding(20,35,20,35);content.addView(hero);content.addView(tv("Álbumes recientes",21));String[] a={"Fallas 2026","Nit Jove 2026","Presentación 2026","REMEMBER RAVAL 26"};for(String s:a)album(s);}
    void album(String s){Button b=btn("📷  "+s+"\n     Ver álbum");b.setOnClickListener(v->showPhotos(s));content.addView(b,new LinearLayout.LayoutParams(-1,95));}
    void showAlbums(){base("Álbumes");content.addView(tv("Todos tus recuerdos",23));String[] a={"Fallas 2026","Nit Jove 2026","Presentación 2026","REMEMBER RAVAL 26"};for(String s:a)album(s);}
    void showPhotos(String name){base(name);content.addView(tv("523 fotos     Todas  ·  Fotos  ·  Vídeos",18));GridLayout g=new GridLayout(this);g.setColumnCount(2);for(int i=1;i<=12;i++){Button p=btn("📸\nFoto "+i);p.setOnClickListener(v->showPhoto(name));g.addView(p,new ViewGroup.LayoutParams(-1,150));}content.addView(g);Button d=btn("⬇ Descargar álbum     ♥ Favorito     ↗ Compartir");d.setOnClickListener(v->Toast.makeText(this,"Acción preparada",Toast.LENGTH_SHORT).show());content.addView(d);}
    void showPhoto(String album){base(album);content.addView(tv("12 de 523",18));TextView p=tv("\n\n             📷\n\n        FOTO DE EJEMPLO\n\n",26);p.setGravity(Gravity.CENTER);content.addView(p);content.addView(btn("♥ Favorito    💬 Comentar    ⬇ Descargar    ↗ Compartir"));}
    void showFavorites(){base("Favoritos");content.addView(tv("Tus fotos favoritas",23));content.addView(tv("Aquí aparecerán las fotos que marques con ♥.",17));}
    void showDownloads(){base("Descargas");content.addView(tv("Tus descargas",23));content.addView(tv("No hay descargas todavía.",17));}
    void showProfile(){base("Mi perfil");content.addView(tv("Mi cuenta",23));Button mode=btn(dark?"☀ Cambiar a modo claro":"🌙 Activar modo noche");mode.setOnClickListener(v->{dark=!dark;prefs.edit().putBoolean("dark",dark).apply();showProfile();});content.addView(mode);content.addView(btn("🔔 Notificaciones"));content.addView(btn("⚙ Configuración"));content.addView(tv("Tarazona Fotos · versión 2.0",15));}
}
