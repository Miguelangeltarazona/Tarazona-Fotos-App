TARAZONA FOTOS APP - PROYECTO ANDROID

Este proyecto incluye el prototipo de Tarazona Fotos App dentro de una aplicación Android.

COMPILACIÓN AUTOMÁTICA
El archivo .github/workflows/build-apk.yml hace que GitHub Actions compile automáticamente
el APK cuando se sube el proyecto al repositorio. También puede ejecutarse manualmente desde
la pestaña Actions.

RESULTADO
El APK se genera como artefacto llamado "Tarazona-Fotos-App" y contiene app-debug.apk.

NOTA
Esta primera versión es una aplicación Android con el prototipo local. Todavía no conecta
la app con Supabase/Dropbox ni sustituye la web Tarazona Fotos.
