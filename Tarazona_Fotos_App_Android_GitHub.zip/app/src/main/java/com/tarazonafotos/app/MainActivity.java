package com.tarazonafotos.app;
import android.app.Activity; import android.os.Bundle; import android.webkit.WebSettings; import android.webkit.WebView; import android.webkit.WebViewClient;
public class MainActivity extends Activity {
@Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);WebView w=findViewById(R.id.webView);WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);w.setWebViewClient(new WebViewClient());w.loadUrl("file:///android_asset/index.html");}
@Override public void onBackPressed(){WebView w=findViewById(R.id.webView);if(w.canGoBack())w.goBack();else super.onBackPressed();}
}